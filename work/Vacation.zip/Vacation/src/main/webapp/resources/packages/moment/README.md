
# FullCalendar Moment Plugin

A connector to the MomentJS date library

[View the docs &raquo;](https://fullcalendar.io/docs/moment-plugins)

This package was created from the [FullCalendar monorepo &raquo;](https://github.com/fullcalendar/fullcalendar)
