package vo;

public class CalVO {

}
