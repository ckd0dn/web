package util;

public class Util {

	public static class Login{
		public static final String VIEW_PATH = "/WEB-INF/views/login/";
	}
	
	public static class Emp{
		public static final String VIEW_PATH = "/WEB-INF/views/emp/";
	}
	
	public static class Vacation{
		public static final String VIEW_PATH = "/WEB-INF/views/vacation/";
	}
}
